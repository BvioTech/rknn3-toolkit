# -*- coding:utf-8 -*-

import os
import copy
import traceback
import platform
from .rknn3_runtime import RKNN3Runtime, RKNN3CoreMask, RKNN3Config
from .rknn3_log import set_log_level_and_file_path
from .rknn3_lite_llm import RKNN3Lite_LLM
from .rknn3_types import (
    RKNN3Lora,
    RKNN3KVCachePolicy,
    RKNN3KVCacheClearPolicy,
    RKNN3KVCachePolicyParam,
    RKNN3LLMParam,
    RKNN3MemAllocFlags,
    RKNN3ImFmt,
    RKNN3ImMem,
    RKNN3TensorMemory,
    RKNN3QueryCmd,
    RKNN3InputOutputNum,
    RKNN3TensorAttr,
    RKNN3SDKVersion,
    RKNN3CoreMemSize,
    RKNN3MemSize,
    RKNN3CustomString,
    RKNN3PerfDetail,
    RKNN3PerfRun,
    RKNN3DevMemInfo,
    RKNN3ShapeConfig,
    RKNN3ShapeInfo,
    RKNN3LLMConfig,
    RKNN3Tensor,
)


class RKNN3Lite:
    RKNN3CoreMask = RKNN3CoreMask
    """
    Rockchip NN Kit
    """
    def __init__(self, llm_mode=False, verbose=False, verbose_file=None):
        self.verbose = verbose
        if verbose_file is not None:
            if os.path.dirname(verbose_file) != "" and not os.path.exists(os.path.dirname(verbose_file)):
                verbose_file = None
        self.rknn_log = set_log_level_and_file_path(verbose, verbose_file)

        # get rknn3-toolkit-lite version
        try:
            import importlib.metadata
            self.rknn_log.w('rknn3-toolkit-lite version: ' +
                            importlib.metadata.version("rknn3-toolkit-lite"))
        except Exception:
            pass

        if verbose:
            if verbose_file is None:
                self.rknn_log.w('Verbose file path is invalid, debug info will not dump to file.')
            else:
                self.rknn_log.d('Save log info to: {}'.format(verbose_file))

        self.rknn_runtime = None
        self.llm = None
        self.rknn_config = RKNN3Config()
        self.model_data = None
        self.weight_data = None
        self.llm_mode = llm_mode


    def load_rknn(self, model_path, weight_path):
        """
        Load RKNN model
        :param model_path: RKNN model file path
        :param weight_path: RKNN weight file path
        :return: success: 0, failure: -1
        """
        if not os.path.exists(weight_path) or not os.path.exists(model_path):
            self.rknn_log.e('Invalid RKNN weight path or model path: {} or {}'.format("None" if (weight_path is None or weight_path == "") else weight_path, 
                                                                                      "None" if (model_path is None or model_path == "") else model_path),
                            False)
            return -1
        try:
            self.model_data = model_path      
            self.weight_data = weight_path       
        except:
            self.rknn_log.e('Catch exception when loading RKNN model [{}, {}]!'.format(weight_path, model_path), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        if self.weight_data is None or self.model_data is None:
            return -1

        return 0

    def init_runtime(self, target, core_mask, llm_args=None, llm_callback=None, llm_embed_path=None, device_id=None):
        """
        Init run time environment. Needed by called before inference or eval performance.
        :param target:Specifies the coprocessor; currently, rk1820/rk1828 are supported.
        :param core_mask: NPU core mask. The co-processor contains 8 NPU cores, and this parameter specifies the enabled cores using a bitmask. For example, 0x0f (binary 0b00001111) indicates the use of the first 4 NPU cores. Note that this parameter must be consistent with the core_mask used when converting the RKNN model; otherwise, an error will occur.
        :param llm_args: A dictionary of configuration parameters for the LLM model.
        :param llm_callback: A callback function for the LLM model, which can be used for streaming inference.
        :param llm_embed_path:The embedding vocabulary path, required to initialize the LLMGetEmbedCallback.
        :return: success: 0, failure: -1
        """
        # self.rknn_log.d('target set by user is: {}'.format(target))
        # if target is None and platform.machine() != 'aarch64' and platform.machine() != 'armv7l':
        #     support_target = 'rk1820 / rk1828'
        #     self.rknn_log.e("RKNN Toolkit Lite3 does not support simulator, please specify the target: {}", False).\
        #         format(support_target)
        #     return -1

        if self.weight_data is None or self.model_data is None:
            self.rknn_log.e("Model is not loaded yet, this interface should be called after load_rknn!", False)
            return -1

        # if rknn_runtime is not None, release it first
        if self.rknn_runtime is not None:
            self.rknn_runtime.destroy()
            self.rknn_runtime = None
        try:
            self.rknn_runtime = RKNN3Runtime(target=target)
        except:
            self.rknn_log.e('Catch exception when load library!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        # rknn_init
        try:
            self.rknn_runtime.rknn_init(device_id=device_id)
        except:
            self.rknn_log.e('Catch exception when init runtime!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        # load rknn model
        try:
            self.rknn_runtime.load_model_from_path(self.model_data, self.weight_data)
        except:
            self.rknn_log.e('Catch exception when load model data!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        # model init
        self.rknn_config.run_core_mask = core_mask
        try:
            ret = self.rknn_runtime.model_init(self.rknn_config)
        except:
            self.rknn_log.e('Catch exception when set npu core mode.', False)
            return -1
        
        # session_init
        if self.llm_mode and (llm_args is not None and llm_callback is not None):
            try:
                self.llm = RKNN3Lite_LLM(self.rknn_runtime.lib, self.rknn_runtime.context, self.rknn_log, llm_args, llm_callback, llm_embed_path)
            except:
                self.rknn_log.e('Catch exception when init llm session!', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
        
        # set tensor
        if not self.llm_mode:
            try:
                self.rknn_runtime.creat_tensor()
            except:
                self.rknn_log.e('Catch exception when creat tensor.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return None

        return ret
    

    def inference(self, inputs=None, data_format=None):
        """
        Run model inference
        :param inputs: Input data List (ndarray list)
        :param data_format: Input format list (str list). Data format (str), current support: 'undefined' 'nhwc' and 'nchw', default is None.
        :return: Output data (ndarray list)
        """
        if self.llm is not None:
             self.rknn_log.e('This interface is only for RKNN model inference, please use session_run for LLM model inference!', False)
             return None

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None
        
        if inputs is None:
            self.rknn_log.e('inputs is None, the model requires input', False)
            return None

        if not isinstance(inputs, list) or len(inputs) == 0:
            self.rknn_log.e('inputs must be a non-empty list', False)
            return None

        if data_format is not None:
            if not isinstance(data_format, list) or len(data_format) == 0:
                self.rknn_log.e('data_format must be a non-empty list', False)
                return None
            if len(data_format) != len(inputs):
                self.rknn_log.e('data_format length is not equal to inputs length', False)
                return None        

        # set inputs
        try:
            self.rknn_runtime.set_input_tensor(inputs, data_format)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret = self.rknn_runtime.run()
        except:
            self.rknn_log.e('Catch exception when running RKNN model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        try:
            outputs = self.rknn_runtime.get_outputs()
        except:
            self.rknn_log.e('Catch exception when getting outputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return outputs

    
    def session_run(self, inputs=None, prompt=None, embeds=None, keep_history=None, max_new_tokens=None, enable_thinking=False):
        """
        Run model inference
        :param inputs: Input data list for multimodal models. Type is list, elements can be RKNN3Image, RKNN3Audio, RKNN3Video, or RKNN3AuxTensor.
        :param prompt: Text prompt input for LLM models, used in multimodal or auxiliary input scenarios.
        :param embeds: Input embedding vectors for LLM models. The type is ndarray.
        :param keep_history: Whether to keep the history context during inference, which may affect the performance. The type is bool, and the default value is None, which means using the default setting of the model.
        :param max_new_tokens: The maximum number of tokens to be generated during inference, which may affect the performance. The type is int, and the default value is None, which means using the default setting of the model.
        :param enable_thinking: Whether to enable thinking mode during inference, which may affect the performance. The type is bool, and the default value is False, which means not using thinking mode.
        :return: ret (0 for success, -1 for failure), and performance stats list [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]
        """

        if self.llm is None:
            self.rknn_log.e('RKNN session_run init failed, please call init_runtime or init_llm_session first!', False)
            return -1, []

        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.llm.inference(prompt=prompt, embeds=embeds, inputs=inputs, keep_history=keep_history, max_new_tokens=max_new_tokens, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when running LLM model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, []
        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def get_sdk_version(self):
        """
        Get SDK version
        :return: sdk_version
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            sdk_version, _, _ = self.rknn_runtime.get_sdk_version()
        except:
            self.rknn_log.e('Catch exception when get sdk version', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return sdk_version
    
    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix):
        """
        Set chat template for LLM model
        :param system_prompt: System prompt
        :param prompt_prefix: Prompt prefix
        :param prompt_postfix: Prompt postfix
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        try:
            ret = self.llm.set_chat_template(system_prompt, prompt_prefix, prompt_postfix)
        except:
            self.rknn_log.e('Catch exception when setting chat template.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret

    def get_devices_id(self):
        """
        Get devices id
        :return: id
        """
        rknn_runtime = RKNN3Runtime(target="rk1820")
        list_devices = rknn_runtime.list_devices()
        devices = []
        if list_devices.n_devices > 0:
            for i in range(list_devices.n_devices):
                devices.append(list_devices.devices[i].id)
        rknn_runtime.release()
        return devices
    
    def get_inputs_tensor_attr(self):
        """
        Get input tensor attribute
        :return: inputs tensor attribute
        """
        if self.llm is not None:
            input_attr =  self.llm.rknn_session.get_inputs_tensor_attr()
        else:
            if self.rknn_runtime is None:
                self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
                return None

            try:
                input_attr = self.rknn_runtime.get_inputs_tensor_attr()
            except:
                self.rknn_log.e('Catch exception when getting input tensor attribute.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return None
            
        if input_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')

        return input_attr
    
    def get_outputs_tensor_attr(self):
        """
        Get output tensor attribute
        :return: outputs tensor attribute
        """
        if self.llm is not None:
            return self.llm.rknn_session.get_outputs_tensor_attr()

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            output_attr = self.rknn_runtime.get_outputs_tensor_attr()
        except:
            self.rknn_log.e('Catch exception when getting output tensor attribute.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        if output_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')  

        return output_attr

    # ============================================= LoRA =============================================

    def init_lora(self, lora_weight_path=None, weight_data=None, weight_size=None):
        """
        Initialize LoRA support by loading LoRA weight data.
        :param lora_weight_path: Path to the LoRA weight file or directory.
        :param weight_data: Optional in-memory LoRA weight data. Supports bytes/bytearray/memoryview, numpy ndarray, or raw pointer.
        :param weight_size: Size of weight_data in bytes, required when weight_data is a raw pointer.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.init_lora(lora_weight_path, weight_data, weight_size)
        except:
            self.rknn_log.e('Catch exception when init lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def load_lora(self, lora):
        """
        Load a LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.load_lora(lora)
        except:
            self.rknn_log.e('Catch exception when load lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def unload_lora(self, lora):
        """
        Unload a previously loaded LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.unload_lora(lora)
        except:
            self.rknn_log.e('Catch exception when unload lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def enable_lora(self, lora):
        """
        Enable a LoRA adapter for inference.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.enable_lora(lora)
        except:
            self.rknn_log.e('Catch exception when enable lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def disable_lora(self, lora):
        """
        Disable a LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.disable_lora(lora)
        except:
            self.rknn_log.e('Catch exception when disable lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def query_lora(self):
        """
        Query loaded LoRA information.
        :return: Tuple of (lora_list, n_lora) on success, or (None, 0) on failure.
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return None, 0

        try:
            lora_list, n_lora = self.llm.query_lora()
        except:
            self.rknn_log.e('Catch exception when query lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None, 0
        return lora_list, n_lora

    # ============================================= KV Cache =============================================

    def set_kvcache_policy(self, policy, param=None):
        """
        Set the KV cache policy for the LLM session.
        :param policy: RKNN3KVCachePolicy enum value.
        :param param: RKNN3KVCachePolicyParam structure, or None for default.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_kvcache_policy(policy, param)
        except:
            self.rknn_log.e('Catch exception when set kvcache policy.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def load_kvcache(self, kvcache_path=None, kvcache_data=None, size=0):
        """
        Load KV cache from a file path or from data.
        :param kvcache_path: Path to the KV cache file.
        :param kvcache_data: Pointer to the KV cache data in memory.
        :param size: Size of the KV cache data in bytes (required when loading from data).
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.load_kvcache(kvcache_path, kvcache_data, size)
        except:
            self.rknn_log.e('Catch exception when load kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def save_kvcache(self, kvcache_path):
        """
        Save KV cache to a file.
        :param kvcache_path: Path where the KV cache will be saved.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.save_kvcache(kvcache_path)
        except:
            self.rknn_log.e('Catch exception when save kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def clear_kvcache(self, clear_policy=None):
        """
        Clear KV cache.
        :param clear_policy: RKNN3KVCacheClearPolicy enum value, or None for RKNN3_KVCACHE_CLEAR_ALL.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.clear_kvcache(clear_policy)
        except:
            self.rknn_log.e('Catch exception when clear kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Session Control =============================================

    def session_run_async(self, inputs=None, prompt=None, embeds=None, keep_history=None, max_new_tokens=None, enable_thinking=False):
        """
        Run LLM model inference asynchronously.
        :param inputs: Input data list for multimodal models. Type is list, elements can be RKNN3Image, RKNN3Audio, RKNN3Video, or RKNN3AuxTensor.
        :param prompt: Text prompt input for LLM models.
        :param embeds: Input embedding vectors for LLM models. The type is ndarray.
        :param keep_history: Whether to keep the history context during inference.
        :param max_new_tokens: The maximum number of tokens to be generated during inference.
        :param enable_thinking: Whether to enable thinking mode during inference.
        :return: ret (0 for success, -1 for failure), and performance stats list [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1, []

        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.llm.inference_async(
                prompt=prompt, embeds=embeds, inputs=inputs,
                keep_history=keep_history, max_new_tokens=max_new_tokens,
                enable_thinking=enable_thinking
            )
        except:
            self.rknn_log.e('Catch exception when running LLM model async.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, []
        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def session_stop(self):
        """
        Stop the running LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.stop()
        except:
            self.rknn_log.e('Catch exception when stop session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_pause(self):
        """
        Pause the running LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.pause()
        except:
            self.rknn_log.e('Catch exception when pause session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_resume(self):
        """
        Resume a paused LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.resume()
        except:
            self.rknn_log.e('Catch exception when resume session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_query_state(self):
        """
        Query the current state of the LLM session.
        :return: RKLLMRunState on success, or None on failure.
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return None

        try:
            state = self.llm.query_state()
        except:
            self.rknn_log.e('Catch exception when query session state.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return state

    # ============================================= Function Tools =============================================

    def set_function_tools(self, tools):
        """
        Set function tools for the LLM session (function calling).
        :param tools: Function tools string (JSON format).
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_function_tools(tools)
        except:
            self.rknn_log.e('Catch exception when set function tools.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= LLM Param =============================================

    def set_llm_param(self, params, n_params=1):
        """
        Set the LLM parameters for an already initialized session.
        :param params: RKNN3LLMParam structure or pointer.
        :param n_params: Number of LLM parameters.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_session_llm_param(params, n_params)
        except:
            self.rknn_log.e('Catch exception when set llm param.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Context =============================================

    def dup_context(self):
        """
        Duplicate the current RKNN3 context.
        :return: Tuple of (ret, new_context). ret is 0 on success, -1 on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1, None

        try:
            ret, new_context = self.rknn_runtime.dup_context()
        except:
            self.rknn_log.e('Catch exception when dup context.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, None
        return ret, new_context

    # ============================================= Async Inference =============================================

    def inference_async(self, inputs=None, data_format=None):
        """
        Run model inference asynchronously (non-LLM).
        Must call wait() to get the results after this call.
        :param inputs: Input data List (ndarray list)
        :param data_format: Input format list (str list). Data format (str), current support: 'undefined' 'nhwc' and 'nchw', default is None.
        :return: success: 0, failure: -1
        """
        if self.llm is not None:
            self.rknn_log.e('This interface is only for RKNN model async inference, please use session_run_async for LLM model!', False)
            return -1

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        if inputs is None:
            self.rknn_log.e('inputs is None, the model requires input', False)
            return -1

        if not isinstance(inputs, list) or len(inputs) == 0:
            self.rknn_log.e('inputs must be a non-empty list', False)
            return -1

        if data_format is not None:
            if not isinstance(data_format, list) or len(data_format) == 0:
                self.rknn_log.e('data_format must be a non-empty list', False)
                return -1
            if len(data_format) != len(inputs):
                self.rknn_log.e('data_format length is not equal to inputs length', False)
                return -1

        # set inputs
        try:
            self.rknn_runtime.set_input_tensor(inputs, data_format)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        # run async
        try:
            ret = self.rknn_runtime.run_async()
        except:
            self.rknn_log.e('Catch exception when running RKNN model async.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret

    def wait(self):
        """
        Wait for the completion of async inference (non-LLM).
        Call get_outputs() after this to retrieve results.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.wait()
        except:
            self.rknn_log.e('Catch exception when waiting for async inference.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def get_outputs(self):
        """
        Get model inference outputs (non-LLM). Call after run() or wait().
        :return: Output data (ndarray list), or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            outputs = self.rknn_runtime.get_outputs()
        except:
            self.rknn_log.e('Catch exception when getting outputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return outputs

    # ============================================= Memory =============================================

    def create_mem(self, attr, tensor=None, flags=RKNN3MemAllocFlags.RKNN3_FLAG_MEMORY_CACHEABLE):
        import ctypes
        """
        创建并绑定张量内存
        :param attr: 从 rknn3_query 获取的 RKNN3TensorAttr 实例
        :param tensor: 可选，RKNN3Tensor 实例。如果提供，将自动填充其 attr 和 mem 字段
        :param flags: 内存分配标志
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited!', False)
            return None

        try:
            if not isinstance(attr, RKNN3TensorAttr):
                self.rknn_log.e('Invalid RKNN3TensorAttr instance.', False)
                return None

            # 1. 从 attr 中提取必要信息
            size = attr.aligned_size
            core_id = attr.core_id
            
            # 2. 调用底层接口创建内存
            mem = self.rknn_runtime.create_mem(size, core_id, flags)
            if mem is None:
                return None

            # 3. 如果提供了 tensor 对象，进行内部绑定（对客户隐藏复杂性）
            if tensor is not None:
                if not isinstance(tensor, RKNN3Tensor):
                    self.rknn_log.e('Invalid RKNN3Tensor instance.', False)
                    return None
                    
                # 自动处理 ctypes 指针和内存拷贝
                attr_ptr = ctypes.pointer(RKNN3TensorAttr())
                ctypes.memmove(attr_ptr, ctypes.addressof(attr), ctypes.sizeof(RKNN3TensorAttr))
                
                # 自动赋值
                tensor.attr = attr_ptr
                tensor.mem = mem
                
            return mem
        except Exception:
            self.rknn_log.e(f'Catch exception when creating memory: {traceback.format_exc()}', False)
            return None

    def create_mem_from_phys(self, phys_addr, virt_addr, size):
        """
        Create tensor memory from physical address.
        :param phys_addr: Physical address of the memory.
        :param virt_addr: Virtual address of the memory.
        :param size: Size of the memory in bytes.
        :return: Pointer to RKNN3TensorMemory, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            mem = self.rknn_runtime.create_mem_from_phys(phys_addr, virt_addr, size)
        except:
            self.rknn_log.e('Catch exception when creating memory from physical address.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return mem

    def create_mem_from_fd(self, fd, virt_addr, size, offset=0):
        """
        Create tensor memory from file descriptor.
        :param fd: File descriptor for the memory.
        :param virt_addr: Virtual address of the memory.
        :param size: Size of the memory in bytes.
        :param offset: Offset from the start of the memory.
        :return: Pointer to RKNN3TensorMemory, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            mem = self.rknn_runtime.create_mem_from_fd(fd, virt_addr, size, offset)
        except:
            self.rknn_log.e('Catch exception when creating memory from fd.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return mem

    def destroy_mem(self, mem):
        """
        Destroy tensor memory.
        :param mem: Pointer to RKNN3TensorMemory to destroy.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.destroy_mem(mem)
        except:
            self.rknn_log.e('Catch exception when destroying memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def mem_sync(self, mem, sync_mode):
        """
        Synchronize tensor memory between CPU and device.
        :param mem: Pointer to RKNN3TensorMemory.
        :param sync_mode: RKNN3MemSyncMode enum value.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.mem_sync(mem, sync_mode)
        except:
            self.rknn_log.e('Catch exception when syncing memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Dynamic Shape =============================================

    def set_shape(self, shape_id):
        """
        Set the model shape for dynamic input.
        :param shape_id: The ID of the shape to be set.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_shape(shape_id)
        except:
            self.rknn_log.e('Catch exception when setting shape.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= User Memory =============================================

    def set_kvcache_mem(self, mem_list, npu_core_indices):
        """
        Set KV-Cache memory for specified NPU cores.
        :param mem_list: List of POINTER(RKNN3TensorMemory) for each core.
        :param npu_core_indices: List of NPU core indices.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_kvcache_mem(mem_list, npu_core_indices)
        except:
            self.rknn_log.e('Catch exception when setting kvcache memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def set_internal_mem(self, mem_list):
        """
        Set user-allocated internal memory for multiple cores.
        :param mem_list: List of POINTER(RKNN3TensorMemory), each mem's core_id specifies the target core.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_internal_mem(mem_list)
        except:
            self.rknn_log.e('Catch exception when setting internal memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Debug & Profile =============================================

    def dump_features(self, dump_dir):
        """
        Dump layer-by-layer features of the model to .npy files.
        :param dump_dir: Directory where dumped features will be saved.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.dump_features(dump_dir)
        except:
            self.rknn_log.e('Catch exception when dumping features.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def profile_ops(self, log_level=0):
        """
        Print layer-by-layer operator profile information.
        :param log_level: Log verbosity level:
                          0 - Only print OpType summary table
                          1 - Print per-Op details table + summary table
                          2 - Print per-Op details (time/cycles/bandwidth) + summary table
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.profile_ops(log_level)
        except:
            self.rknn_log.e('Catch exception when profiling ops.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def profile_mem(self):
        """
        Print memory usage information for each NPU core.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.profile_mem()
        except:
            self.rknn_log.e('Catch exception when profiling memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Custom Operator =============================================

    def register_custom_ops_plugins(self, plugin_path):
        """
        Register custom operator plugins from a shared library.
        :param plugin_path: Path to the plugin shared library file (.so).
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.register_custom_ops_plugins(plugin_path)
        except:
            self.rknn_log.e('Catch exception when registering custom ops plugins.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Image Processing =============================================

    def im_mem_create(self, width, height, fmt, size=0, core_id=0,
                      flags=RKNN3MemAllocFlags.RKNN3_FLAG_MEMORY_CACHEABLE):
        """
        Create image memory.
        :param width: Width of the image.
        :param height: Height of the image.
        :param fmt: Image format (RKNN3ImFmt enum value).
        :param size: Size in bytes. If 0, calculated from width/height/format.
        :param core_id: Target NPU core ID.
        :param flags: Memory allocation flags.
        :return: Tuple of (ret, RKNN3ImMem). ret is 0 on success, -1 on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1, None

        try:
            ret, im_mem = self.rknn_runtime.im_mem_create(width, height, fmt, size, core_id, flags)
        except:
            self.rknn_log.e('Catch exception when creating image memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, None
        return ret, im_mem

    def im_mem_destroy(self, im_mem):
        """
        Destroy image memory.
        :param im_mem: RKNN3ImMem object to destroy.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.im_mem_destroy(im_mem)
        except:
            self.rknn_log.e('Catch exception when destroying image memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def im_cvt_color(self, src_im_mem, dst_im_mem):
        """
        Convert image color space.
        :param src_im_mem: Source RKNN3ImMem object.
        :param dst_im_mem: Destination RKNN3ImMem object.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.im_cvt_color(src_im_mem, dst_im_mem)
        except:
            self.rknn_log.e('Catch exception when converting image color.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Output Tensors =============================================

    def create_output_tensors(self, output_indices=None):
        """
        Create output tensors with allocated memory for LLM output callback.
        Mirrors the C++ pattern:
            for each output index:
                rknn3_query(RKNN3_QUERY_OUTPUT_ATTR) -> get attr
                rknn3_create_mem(aligned_size, core_id, CACHEABLE) -> allocate mem
                build RKNN3Tensor with attr + mem

        :param output_indices: List of output tensor indices. If None, uses all outputs (0..n_output-1).
        :return: Tuple of (output_tensor_array, n_output_tensors) on success, or (None, 0) on failure.
                 output_tensor_array is a ctypes array of RKNN3Tensor.
        """
        from ctypes import pointer, memmove, sizeof, cast, POINTER

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None, 0

        try:
            # If no indices specified, query IO num and use all outputs
            if output_indices is None:
                io_num = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_IN_OUT_NUM)
                if io_num is None:
                    self.rknn_log.e('Failed to query IO number.', False)
                    return None, 0
                output_indices = list(range(io_num.n_output))

            n_output_tensors = len(output_indices)
            if n_output_tensors == 0:
                self.rknn_log.e('No output tensor indices specified.', False)
                return None, 0

            # Allocate ctypes array of RKNN3Tensor
            OutputTensorArray = RKNN3Tensor * n_output_tensors
            output_tensors = OutputTensorArray()

            for i, idx in enumerate(output_indices):
                attr = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_OUTPUT_ATTR, index=idx)
                if attr is None:
                    self.rknn_log.e('rknn3_query output attr failed for index {}'.format(idx), False)
                    return None, 0

                attr_ptr = pointer(RKNN3TensorAttr())
                memmove(attr_ptr, pointer(attr), sizeof(RKNN3TensorAttr))
                output_tensors[i].attr = attr_ptr

                # Create memory directly from attr (aligned_size + core_id extracted inside create_mem)
                mem = self.create_mem(attr)
                if mem is None:
                    self.rknn_log.e('Failed to create memory for output tensor {}'.format(i), False)
                    return None, 0
                output_tensors[i].mem = mem

            return output_tensors, n_output_tensors

        except:
            self.rknn_log.e('Catch exception when creating output tensors.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None, 0

    def release(self):
        """
        Release RKNN resource
        :return: None
        """
        # release rknn session
        if self.llm is not None:
            self.llm.release()
            self.llm = None
        # release rknn runtime
        if self.rknn_runtime is not None:
            self.rknn_runtime.release()
            self.rknn_runtime = None

    # ============================================= Query =============================================

    def rknn3_query(self, cmd, index=0):
        """
        General-purpose query interface, similar to the C API rknn3_query.
        Allows querying model information after init_runtime (model_init) but before
        init_llm_session, enabling a query-then-configure workflow like the C++ API.

        Supported commands:
            RKNN3_QUERY_IN_OUT_NUM          -> RKNN3InputOutputNum
            RKNN3_QUERY_INPUT_ATTR          -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_OUTPUT_ATTR         -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_INPUT_ATTR   -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_OUTPUT_ATTR  -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR  -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_SDK_VERSION         -> RKNN3SDKVersion
            RKNN3_QUERY_CORE_NUMBER         -> c_uint32 (core_number.value)
            RKNN3_QUERY_CORE_MEM_SIZE       -> RKNN3CoreMemSize (use index to specify core_id)
            RKNN3_QUERY_DEVICE_MEM_INFO     -> RKNN3DevMemInfo
            RKNN3_QUERY_CUSTOM_STRING       -> RKNN3CustomString
            RKNN3_QUERY_PERF_DETAIL         -> RKNN3PerfDetail
            RKNN3_QUERY_PERF_RUN            -> RKNN3PerfRun
            RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG -> RKNN3ShapeConfig
            RKNN3_QUERY_DYNAMIC_SHAPE_INFO  -> RKNN3ShapeInfo (use index param for shape_id)
            RKNN3_QUERY_LLM_CONFIG          -> RKNN3LLMConfig
            RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM -> RKNN3InputOutputNum
            RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO -> RKNN3ShapeInfo (use index param)

        :param cmd: RKNN3QueryCmd enum value.
        :param index: Index for tensor attribute queries (input/output index) or core_id for core queries.
        :return: Query result structure on success, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        from ctypes import pointer, cast, c_void_p, sizeof, c_uint32

        try:
            cmd_val = int(cmd)

            # RKNN3_QUERY_IN_OUT_NUM / RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM
            if cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_IN_OUT_NUM,
                           RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM):
                info = RKNN3InputOutputNum()

            # Tensor attribute queries (input/output)
            elif cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR):
                info = RKNN3TensorAttr()
                info.index = index

            # SDK version
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_SDK_VERSION:
                info = RKNN3SDKVersion()

            # Core number
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CORE_NUMBER:
                info = c_uint32(0)
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(pointer(info), c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query CORE_NUMBER failed. error code: {}'.format(ret), False)
                    return None
                return info.value

            # Core memory size
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CORE_MEM_SIZE:
                info = RKNN3CoreMemSize()
                info.core_id = index

            # Device memory info
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_DEVICE_MEM_INFO:
                info = RKNN3DevMemInfo()

            # Custom string
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CUSTOM_STRING:
                info = RKNN3CustomString()

            # Performance detail
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_PERF_DETAIL:
                info = RKNN3PerfDetail()

            # Performance run
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_PERF_RUN:
                info = RKNN3PerfRun()

            # Dynamic shape config
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG:
                info = RKNN3ShapeConfig()

            # Dynamic shape info / Postprocess dynamic shape info
            elif cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_DYNAMIC_SHAPE_INFO,
                             RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO):
                info = RKNN3ShapeInfo()
                info.shape_id = index

            # LLM config
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LLM_CONFIG:
                info = RKNN3LLMConfig()

            # LoRA number
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LORA_NUM:
                info = c_uint32(0)
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(pointer(info), c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query LORA_NUM failed. error code: {}'.format(ret), False)
                    return None
                return info.value

            # LoRA information
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LORA_INFO:
                n_lora = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_LORA_NUM)
                if n_lora is None:
                    self.rknn_log.e('Failed to query LoRA number.', False)
                    return None
                if n_lora == 0:
                    return []
                info = (RKNN3Lora * n_lora)()
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(info, c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query LORA_INFO failed. error code: {}'.format(ret), False)
                    return None
                return list(info)

            else:
                self.rknn_log.e('Unsupported query command: {}'.format(cmd), False)
                return None

            result = self.rknn_runtime.rknn3_query(cmd_val, info)
            return result

        except:
            self.rknn_log.e('Catch exception when querying.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

    # ============================================= Separated Init Flow =============================================

    def init_llm_session(self, llm_args, llm_callback=None, llm_embed_path=None):
        """
        Initialize the LLM session separately from init_runtime.
        This allows a query-then-configure workflow similar to the C++ API:
            1. load_rknn(model_path, weight_path)
            2. init_runtime(target, core_mask)          # rknn3_init + load + model_init only
            3. rknn3_query(...)                          # query model info (IO, core num, mem size, etc.)
            4. init_llm_session(llm_args, callback)      # rknn3_session_init + set_callback
            5. set_internal_mem(...) / other config       # configure shared memory, etc.
            6. session_run(...)                           # inference

        :param llm_args: A dictionary (or list of dict) of configuration parameters for the LLM model.
        :param llm_callback: A callback function (dict or RKLLMCallback structure) for the LLM model.
        :param llm_embed_path: The embedding vocabulary path, required for LLMGetEmbedCallback.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime first!', False)
            return -1

        if self.llm is not None:
            self.rknn_log.e('LLM session is already initialized. Call release() first if you want to re-initialize.', False)
            return -1

        try:
            self.llm = RKNN3Lite_LLM(
                self.rknn_runtime.lib,
                self.rknn_runtime.context,
                self.rknn_log,
                llm_args,
                llm_callback,
                llm_embed_path
            )
            self.llm_mode = True
        except:
            self.rknn_log.e('Catch exception when init llm session!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return 0
