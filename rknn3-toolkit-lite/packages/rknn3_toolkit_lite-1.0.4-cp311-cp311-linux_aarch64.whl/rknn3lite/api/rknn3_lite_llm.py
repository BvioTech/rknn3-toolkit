from .rknn3_session import RKNN3Session

import traceback


class RKNN3Lite_LLM():
    def __init__(self, lib, context, rknn_log, args, callback, embed_path):
        self.context = context
        self.rknn_log = rknn_log
        self.rknn_session = RKNN3Session(lib, context)

        try:
            self.rknn_session.set_llm_param(args)
        except:
            self.rknn_log.e('Catch exception when set llm param!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        try:
            self.rknn_session.init()
        except:
            self.rknn_log.e('Catch exception when init session!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        try:
            self.rknn_session.set_callback(callback, embed_path)
        except:
            self.rknn_log.e('Catch exception when set callback!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        pass

    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix):  
        return self.rknn_session.set_chat_template(system_prompt, prompt_prefix, prompt_postfix)

    def inference(self, prompt, embeds, inputs, keep_history=None, max_new_tokens=None, enable_thinking=False):

        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds only support one.")

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run(keep_history, max_new_tokens)
        except:
            self.rknn_log.e('Catch exception when running RKNN model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def inference_async(self, prompt, embeds, inputs, keep_history=None, max_new_tokens=None, enable_thinking=False):
        """Run LLM inference asynchronously.

        :param keep_history: Whether to keep history, overrides infer_param if not None.
        :param max_new_tokens: Maximum number of new tokens, overrides infer_param if not None.
        :param enable_thinking: Whether to enable thinking mode for this request.
        """
        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds only support one.")

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run async
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run_async(keep_history, max_new_tokens)
        except:
            self.rknn_log.e('Catch exception when running RKNN model async.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    # LoRA
    def init_lora(self, lora_weight_path=None, weight_data=None, weight_size=None):
        """Initialize LoRA from file path or memory buffer."""
        return self.rknn_session.init_lora(lora_weight_path, weight_data, weight_size)

    def load_lora(self, lora):
        return self.rknn_session.load_lora(lora)

    def unload_lora(self, lora):
        return self.rknn_session.unload_lora(lora)

    def enable_lora(self, lora):
        return self.rknn_session.enable_lora(lora)

    def disable_lora(self, lora):
        return self.rknn_session.disable_lora(lora)

    def query_lora(self):
        return self.rknn_session.query_lora()

    # KV Cache
    def set_kvcache_policy(self, policy, param=None):
        return self.rknn_session.set_kvcache_policy(policy, param)

    def load_kvcache(self, kvcache_path=None, kvcache_data=None, size=0):
        return self.rknn_session.load_kvcache(kvcache_path, kvcache_data, size)

    def save_kvcache(self, kvcache_path):
        return self.rknn_session.save_kvcache(kvcache_path)

    def clear_kvcache(self, clear_policy=None):
        if clear_policy is not None:
            return self.rknn_session.clear_kvcache(clear_policy)
        return self.rknn_session.clear_kvcache()

    # Session control
    def stop(self):
        return self.rknn_session.stop()

    def pause(self):
        return self.rknn_session.pause()

    def resume(self):
        return self.rknn_session.resume()

    def query_state(self):
        return self.rknn_session.query_state()

    # Function tools
    def set_function_tools(self, tools):
        return self.rknn_session.set_function_tools(tools)

    # LLM param
    def set_session_llm_param(self, params, n_params=1):
        return self.rknn_session.set_session_llm_param(params, n_params)

    def release(self):
        if self.rknn_session is not None:
            self.rknn_session.destroy()
            self.rknn_session = None